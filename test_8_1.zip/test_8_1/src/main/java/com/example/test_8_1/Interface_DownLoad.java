package com.example.test_8_1;

/**
 * Created by Administrator on 2016/8/1.
 */
public interface Interface_DownLoad  {
    public void getData(MyGson myGson);
}
