package com.example.test7_4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    MyAdapter myAdapter;
    List<HashMap<String,Object>> hashMapList = new ArrayList<>();
    HashMap<String,Object> hashMap1 ;
    HashMap<String,Object> hashMap2 ;
    HashMap<String,Object> hashMap3 ;
    HashMap<String,Object> hashMap4 ;

    List<HashMap<String,Object>> hashMapList_temp = new ArrayList<>();

    //头像id
    int[] imgID = new int[]{
            R.mipmap.text1,R.mipmap.text2,R.mipmap.text11,R.mipmap.text3,
    };

    //title
    String[] strTitle = new String[]{"学生1","学生2","学生3","学生4"};

    //context
    String[] strContext = new String[]{"这是学生1","这是学生2","这是学生3","这是学生4"};

    ListView listView;
    Button button_Tianjia;
    Button button_Jianshao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        button_Tianjia.setOnClickListener(this);
        button_Jianshao.setOnClickListener(this);
        hashMap1 = new HashMap<>();
        hashMap2 = new HashMap<>();
        hashMap3 = new HashMap<>();
        hashMap4 = new HashMap<>();
        hashMap1.put("imgID",imgID[0]);
        hashMap2.put("imgID",imgID[1]);
        hashMap3.put("imgID",imgID[2]);
        hashMap4.put("imgID",imgID[3]);
        hashMap1.put("strTitle",strTitle[0]);
        hashMap2.put("strTitle",strTitle[1]);
        hashMap3.put("strTitle",strTitle[2]);
        hashMap4.put("strTitle",strTitle[3]);
        hashMap1.put("strContext",strContext[0]);
        hashMap2.put("strContext",strContext[1]);
        hashMap3.put("strContext",strContext[2]);
        hashMap4.put("strContext",strContext[3]);

//        hashMap1.put("time",System.currentTimeMillis());
//        hashMap2.put("time",System.currentTimeMillis());
//        hashMap3.put("time",System.currentTimeMillis());
//        hashMap4.put("time",System.currentTimeMillis());

        hashMapList_temp.add(hashMap1);
        hashMapList_temp.add(hashMap2);
        hashMapList_temp.add(hashMap3);
        hashMapList_temp.add(hashMap4);

        myAdapter = new MyAdapter(this.hashMapList,MainActivity.this);
        listView.setAdapter(myAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            Intent intent1 = new Intent(MainActivity.this,Student1_Activity.class);
            Intent intent2 = new Intent(MainActivity.this,Student2_Activity.class);
            Intent intent3 = new Intent(MainActivity.this,Student3_Activity.class);
            Intent intent4 = new Intent(MainActivity.this,Student4_Activity.class);
            Intent[] intents = new Intent[]{intent1,intent2,intent3,intent4};
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        startActivity(intents[position]);
            }
        });
    }

    public void init(){
        listView = (ListView) findViewById(R.id.id_main_lv);
//        for(int i = 0 ; i< imgID.length ; i++){
//            HashMap<String,Object> hashMap = new HashMap<>();
//            hashMap.put("icon",imgID[i]);
//            hashMap.put("title",strTitle[i]);
//            hashMap.put("context",strContext[i]);
//            hashMapList.add(hashMap);
//        }
        button_Tianjia = (Button) findViewById(R.id.id_main_btn_tianjia);
        button_Jianshao = (Button) findViewById(R.id.id_main_btn_jianshao);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.id_main_btn_tianjia:
                if(hashMapList_temp.size()>0){
                    hashMapList.add(hashMapList_temp.get(0));
                    hashMapList_temp.remove(0);
                    myAdapter.notifyDataSetChanged();
                }else {
                    Toast.makeText(MainActivity.this,"已经没有学生信息可以添加",Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.id_main_btn_jianshao:
                if(hashMapList.size()>0){
                    hashMapList_temp.add(hashMapList.get(hashMapList.size()-1));
                    hashMapList.remove(hashMapList.size()-1);
                    myAdapter.notifyDataSetChanged();
                }else {
                    Toast.makeText(MainActivity.this,"已经没有学生信息可以删除",Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }


}
