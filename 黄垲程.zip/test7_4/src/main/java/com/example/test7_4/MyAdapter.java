package com.example.test7_4;

import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


/**
 * Created by Administrator on 2016/7/4.
 */
public class MyAdapter extends BaseAdapter {
    MainActivity mainActivity;
    List<HashMap<String,Object>> hashMapList ;

    public MyAdapter(List<HashMap<String,Object>> hashMapList,MainActivity mainActivity){
        this.hashMapList = hashMapList;
        this.mainActivity = mainActivity;
    }

    @Override
    public int getCount() {
        return hashMapList.size();
    }

    @Override
    public Object getItem(int position) {
        return hashMapList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = convertView.inflate(this.mainActivity,R.layout.list_item,null);
        ImageView imageView = (ImageView) convertView.findViewById(R.id.id_listitem_iv_icon);
        TextView textView_Title = (TextView) convertView.findViewById(R.id.id_listitem_tv_title);
        TextView textView_Context = (TextView) convertView.findViewById(R.id.id_listitem_tv_context);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH)+1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        TextView textView_Time = (TextView) convertView.findViewById(R.id.id_listitem_tv_time);
        imageView.setImageResource((Integer) hashMapList.get(position).get("imgID"));
        textView_Title.setText((CharSequence) hashMapList.get(position).get("strTitle"));
        textView_Context.setText((CharSequence) hashMapList.get(position).get("strContext"));
        textView_Time.setText( year+"-"+month+"-"+day+"");
        return convertView;
    }
}
